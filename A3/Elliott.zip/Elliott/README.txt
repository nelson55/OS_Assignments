Group: Nelson Elliott

Execute Q1:

./stats int int int int ....


Execute Q2: (Got rid of the package thing so it executes by name now)

java EchoServer
java EchoClient localhost


Pictures show all the things. Thats about it.